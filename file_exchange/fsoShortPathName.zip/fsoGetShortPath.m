function shortPath = fsoGetShortPath(pathName)
%fsoGetShortPath Retrieves the short path form of the specified path.
%
%  fsoGetShortPath(pathName) retrieves the short path form (MS-DOS 8.3) of 
%  the specified path pathName. pathName is a string or a cell of string.
%
%  shortPath = fsoGetShortPath(...) returns a string or a cell of strings.
%
%  fsoGetShortPath is based a COM server (Scripting.FileSystemObject) and 
%  therefore is only supported on Windows systems. For more information, see 
%  <a href="http://msdn.microsoft.com/en-us/library/d6dw7aeh%28v=vs.84%29.aspx">FileSystemObject Introduction</a>.
%
%  Example
%
%    shortPath = fsoGetShortPath('C:\Program Files (x86)\Notepad++\notepad++.exe')
%
%    shortPath =
%
%    C:\PROGRA~2\NOTEPA~1\NOTEPA~1.EXE
%
%  See also fsoGetShortPath.

%  Author  : Jerome Briot
%       http://www.mathworks.com/matlabcentral/fileexchange/authors/21984
%  Contact : dutmatlab at yahoo dot fr

%  Copyright 2015, Jerome Briot

if ~ispc
    error('Only available on Windows');
end

narginchk(1,1);
nargoutchk(0,1);

fso = actxserver('Scripting.FileSystemObject');

if iscell(pathName)   
    if ~all(cellfun('isclass', pathName, 'char'))
        error('First argument must contains strings')
    end
    for n = 1:numel(pathName)        
        shortPath{n} = gsp(pathName{n}, fso);        
    end    
else
    if ~ischar(pathName)
        error('First argument must contains strings')
    end
    shortPath = gsp(pathName, fso);
end

delete(fso);

function shortPath = gsp(pathName, fso)

if isdir(pathName)    
    shortPath = fso.GetFolder(pathName).ShortPath; 
elseif exist(pathName, 'file')==2
    shortPath = fso.GetFile(pathName).ShortPath;
else
    warning('File or folder "%s" not found', pathName);
    shortPath = '';
end